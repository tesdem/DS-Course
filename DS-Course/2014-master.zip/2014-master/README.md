# Welcome to CS109 Data Science

Official course page here: [http://cs109.github.io/2014](http://cs109.github.io/2014)